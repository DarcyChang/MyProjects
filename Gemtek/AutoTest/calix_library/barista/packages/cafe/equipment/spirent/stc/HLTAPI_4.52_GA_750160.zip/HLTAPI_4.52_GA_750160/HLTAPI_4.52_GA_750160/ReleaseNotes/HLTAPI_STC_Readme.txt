======================================================================
Spirent HLTAPI  (hltapi_stc_4.52)                 Date: 08/01/15
======================================================================


Table of Contents
-----------------
        System Requirements (special):
        APIs Supported:
        Changes:
        Key Known Issues:
        General Restrictions:
        Installation Instructions (special):
        

System Requirements (special):
        This release supports Single Processor, Dual Processor, Windows, Enterprise Linux 3, RedHat 8.0
        This release supports Spirent TestCenter Release 4.50/4.52
        TCL 8.4.13 (reuqire tbcload package 1.5 or higher, Tdom 0.8.3 and IP package)
        Cards: MSA2001A/B EDM-2003A, XFP-2001A/B, CPR2001A/B, CPR2002A/B, EDM2001A/B, FBR2001A/B, UPY2001A, UPY2002A, WAN2002A, XFP-4004A, SFP-4001A, CM, CV, DX/DX2, FX/FX2, MX/MX2, VM


APIs Supported:
        Session API
        Alarms
        Traffic API
        Test_config/Test_control
        40G/100G port suport
        Capture, Capture Filter
        BGPv4, BGPv6
        DHCPv4,DHCPv6,DHCP-PD
        STP
        IGMPv1, IGMPv2, IGMPv3, IGMPv1 Querier, IGMPv2 Querier, IGMPv3 Querier
        IS-IS IPv4, IS-IS IPv6
        IPv6 Autoconfiguration
        LDP IPv4
        MLDv1, MLDv2
        Multicast groups
        OSPFv2, OSPFv3
        OSPF Topology
        Ping
        PIM
        PPP, PPPoX/IPv4, pppox server, L2TP
        RIPv1, RIPv2, RIPng 
        RSVP IPv4
        Route flapping for BGP, IS-IS, OSPF, RIP
        BFD
        L2TP
        Graceful restart for BGP, IS-IS, LDP, OSPF, RSVP
        GRE for RSVP, BGP, LDP, OSPF, PIM, RIP
        ATM for BGP, ISIS, OSPF, PPPOx, Pppox Server, RIP, ANCP, L2TP, DHCP, DHCP server
        Ethernet OAM 
        Ethernet EFM
        MVPN
        ANCP
        RFC2544, RFC3918
        LACP
        SIP
        FCOE/FIP, FC
        LLDP
        PTP
        Lab Server mode support
        802.1x
        MPLS-TP
        CFM PDUs Capture Filters.
        Save to High Level API
        Configure multiple protocols on the same device, including RSVP/IGMP/LDP/RIP/OSPFV2/OSPFV3/ISIS/BGP/DHCPV6/DHCPV6PD/DHCPV4/PIM/SIP/MLD/IGMP QUERIER.
        VxLan
        HLTAPI for Perl
        HLTAPI for Python
        Save as iTest
        40G/100G L1 API
        PCEP
        NG-MPVN
        HTTP Client and HTTP server

Changes:
        (from release 4.50 to release 4.52):
        a) New features: 
           none

        b) Enhancement:
            BGP-LS wizard support
            mapping server support in ISIS-SR
            1-2541713953  support '-DisableAutoGrouping' in ::sth::drv_stats()1-2507774241 3 Label Stack for ipv6 (Transport Label, ELI, EL), 5 Label Stack for ipv4/ipv6 (VPN Label, ELI, EL, BGP, Transport Label) support in Raw streamblock.

        c) Issue resolutions:
            1-2575077380  test_rfc2544_info -test_type throughput, summary results are not calculated correctly if the result iterations (multiple interactions) differ from one another.
            1-2569787873  Dependency Error for ip_src_addr. ENTERED: arp. EXPECTED: ipv4
            1-2552396570  in perform: Unable to open /home/eotResultsHltApi113044.db
            1-2533816161  RX frame to be 0 even though the port is receiving traffic
            1-2522703355  HLTAPI Wrapper "emulation_bgp_config" causing the srouce mac to be set to all zero's

Key Known Issues:
   

Installation Instructions:
        Windows, Enterprise Linux 3, RedHat 8.0
        a) Install Spirent P4.52 HLTAPI:
        gunzip hltapi.tar.gz
        tar -vxf hltapi.tar in /tcl/lib folder
        hltapi folder will be created after untarred