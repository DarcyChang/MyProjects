/* udpClient.c 
   Copyright (C) 2005 Craig Brown and Jerry Iseri
   For conditions of distribution and use, see copyright notice in udpClient.h
   $Id: //TestCenter/p2_dev_HltApi/mainline/content/HltAPI/4.46/ReleasePackage/SourceCode/utracker/udpClient.cpp#1 $
*/

#include "udpClient.h"
#include <tcl.h>


#ifdef __BORLANDC__
#define AX_BORLAND_EXPORT _export
#if defined(__cplusplus)
#define STUB_EXPVAL extern "C"
#else
#define STUB_EXPVAL
#endif
#elif defined(WIN_32)
/* Microsoft MSVC */
#define AX_BORLAND_EXPORT
#if defined(__cplusplus)
#define STUB_EXPVAL extern "C" __declspec(dllexport)
#else
#define STUB_EXPVAL __declspec(dllexport)
#endif
#else 
/* UNIX */
#define AX_BORLAND_EXPORT
#if defined(__cplusplus)
#define STUB_EXPVAL extern "C"
#else
#define STUB_EXPVAL
#endif
#define AX_UNIX_PKG 1

#define closesocket close
#define ioctlsocket ioctl
#define INVALID_SOCKET -1
#define SOCKET_ERROR -1
#endif

#define MAX_MSG 512
#define port 1500


#if defined(WIN_32)
/* This is just a dummy to satisfy the DLL entrypoint -- perhaps we'll take
 * care of some things later, but not now. */
BOOL WINAPI DllMain(HANDLE hinstDll, DWORD fdwReason, LPVOID lpvReserved)
{
    (void) hinstDll;
    (void) lpvReserved;
    switch (fdwReason)
    {
    case DLL_PROCESS_ATTACH: /* Actions associated with attaching */
    case DLL_THREAD_ATTACH: /* Actions taken when new threads created */
    case DLL_THREAD_DETACH: /* Actions taken when thread exits */
    case DLL_PROCESS_DETACH: /* Remove DLL from address space */
        break;
    }
    return TRUE;
}

static int Win32_Start_Network(void)
{
    static AX_BOOLEAN wsaInited = AX_FALSE;
    /* Don't have to initialize the winsock once already initialized */
    if (wsaInited == AX_FALSE)
    {
        /* WinSock specific startup */
        WORD wVersionRequested;
        WSADATA wsaData;
        int err;

        wVersionRequested = MAKEWORD(1, 1); /* use 1.1 for Win95 compatibility */
        err = WSAStartup(wVersionRequested, &wsaData);
        if (err != 0)
        {
            /* WSAStartup failed */
            return -1;
        }
        if (LOBYTE( wsaData.wVersion ) != 1 ||
            HIBYTE( wsaData.wVersion ) != 1 )
        {
            /* version mis-match */
            return -2;
        }
        wsaInited = AX_TRUE;
    }
    return 1;
}
#endif

typedef struct 
{
    int ready;  /* 1 - means internal data ready */
    int handle;
    struct sockaddr_in remoteServAddr;
    Tcl_DString server;
} udpClient_t;

static udpClient_t g_Client;
#if defined(WIN_32)
static int g_networkUp;
#endif

int udpc_init(ClientData clientData, Tcl_Interp *interp, int objc, Tcl_Obj
              *CONST objv[]) 
{
    /* Variables for Tcl */
    char * server;
    /* Tcl_Obj * tcl_result; */
    int templength;
    /* clientData = clientData; */
  
    /* Variable for UDP Client */
    int    rc;
    struct sockaddr_in cliAddr;
    struct hostent *h;
    Tcl_Obj *result = Tcl_GetObjResult(interp);

    /* 1st time initialize handle or re-initialize client handle 
       due to socket errors
     */
    if (g_Client.ready || 
        (!g_Client.ready && g_Client.handle != INVALID_SOCKET))
    {
        /* Reset vars if reusing resource*/
        if (g_Client.handle != INVALID_SOCKET)
        {
            closesocket(g_Client.handle);
            g_Client.handle = INVALID_SOCKET;
        }
        /* free any memory */
        Tcl_DStringFree(&g_Client.server);
        g_Client.ready = 0;
    }

#if defined(WIN_32)
    if (! g_networkUp) 
    {
        
        rc = Win32_Start_Network();
        if (rc < 0) 
        {
            Tcl_AppendStringsToObj(result, "udpc: failed to startup Win32 "
                                           "Networking services", (char *)NULL);
            return TCL_ERROR;
        }
        g_networkUp = 1;
    }
#endif
    
    /* check command line args */
    if ( objc < 5 ) {
        Tcl_AppendStringsToObj(result, "usage :  utracker <server> <vendor> <user> "
                                       "<procedure> <optional data>\n", (char *)NULL);
        return TCL_ERROR;
    }

    if (( server = Tcl_GetStringFromObj(objv[1], &templength)) == NULL)
        return TCL_ERROR;

    /* get server IP address (no check if input is IP address or DNS name */
    h = gethostbyname(server);
    if(h==NULL) {
        Tcl_AppendStringsToObj(result, "utracker: unknown host ", 
                               server, "\n", (char *)NULL);
        return TCL_ERROR;
    }
  
    /* printf("%s: sending data to '%s' (IP : %s) %s \n", server, h->h_name,
       inet_ntoa(*(struct in_addr *)h->h_addr_list[0]), msg); */
  
    g_Client.remoteServAddr.sin_family = h->h_addrtype;
    memcpy((char *) &g_Client.remoteServAddr.sin_addr.s_addr, 
           h->h_addr_list[0], h->h_length);
    g_Client.remoteServAddr.sin_port = htons(port);

    /* socket creation */
    g_Client.handle = socket(AF_INET,SOCK_DGRAM,0);
    if(g_Client.handle == INVALID_SOCKET) {
        Tcl_AppendStringsToObj(result,"utracker: cannot open socket \n", 
                               (char *)NULL);
        return TCL_ERROR;
    }
  
    /* bind any port */
    cliAddr.sin_family = AF_INET;
    cliAddr.sin_addr.s_addr = htonl(INADDR_ANY);
    cliAddr.sin_port = htons(0);
  
    rc = bind(g_Client.handle, (struct sockaddr *) &cliAddr, sizeof(cliAddr));
    if(rc == SOCKET_ERROR) {
        char portStr[20];

        closesocket(g_Client.handle);
        g_Client.handle = INVALID_SOCKET;
        sprintf(portStr,"%d ", port);
        Tcl_AppendStringsToObj(result, "utracker: cannot bind port\n", 
                               portStr, (char *)NULL);

#if defined(WIN_32)
        sprintf(portStr,"%d ",WSAGetLastError());
#else
        sprintf(portStr,"%d ", errno);
#endif        
        Tcl_AppendStringsToObj(result, ", failed errno ", portStr, "\n", 
                               (char *)NULL);
        return TCL_ERROR;
    }

    Tcl_DStringAppend(&g_Client.server, server, -1);
    g_Client.ready = 1;
    return TCL_OK;
}
    

int udpc(ClientData clientData, Tcl_Interp *interp, int objc, Tcl_Obj 
         *CONST objv[]) {

    /* Variables for Tcl */
    char * server;
    /* Tcl_Obj * tcl_result; */
    int templength;
    /* clientData = clientData; */
    int n;
  
    /* Variable for UDP Client */
    int rc;
    char *msg;
    /* Used to hold msg */
    Tcl_Obj *msgObj = (Tcl_Obj *)NULL;
    Tcl_Obj *result = Tcl_GetObjResult(interp);

    
    /* check command line args */
    if ( objc < 5 ) {
        Tcl_AppendStringsToObj(result, "usage :  utracker <server> <vendor> <user> <procedure> <optional data>\n", (char *)NULL);
        return TCL_ERROR;
    }

    msgObj = Tcl_NewStringObj(NULL,0);
    if (msgObj == (Tcl_Obj*)NULL)
    {
        Tcl_SetResult(interp,"udpc: Tcl_NewStringObj failed", TCL_STATIC);
        return TCL_ERROR;
    }

    for (n=2; n<objc && n<=5; n++) 
    {
        if ((msg = Tcl_GetStringFromObj(objv[n], &templength)) == NULL)
        {
            Tcl_AppendStringsToObj(result, "failed to get msg from object", (char*)NULL);
            Tcl_IncrRefCount(msgObj);
            Tcl_DecrRefCount(msgObj);
            return TCL_ERROR;
        }
        if ( n != 5 ) 
        {
            Tcl_AppendToObj(msgObj, msg, templength);
            if (n != objc-1)
                Tcl_AppendToObj(msgObj, ",", 1);
        }
        else 
        {
            Tcl_AppendToObj(msgObj, msg, templength);
        }
    }

    Tcl_IncrRefCount(msgObj);
    if (( server = Tcl_GetStringFromObj(objv[1], &templength)) == NULL)
    {
        if (msgObj) Tcl_DecrRefCount(msgObj);   
        return TCL_ERROR;
    }

    /* client socket not ready or server name changed re-init */
    if (! g_Client.ready ||
        (strcmp(Tcl_DStringValue(&g_Client.server), server) != 0))
    {
        if ((rc = udpc_init(clientData, interp, objc, objv)) != TCL_OK)
        {
            if (msgObj) Tcl_DecrRefCount(msgObj);
            return rc;
        }
        
    }

    /* send data */
    msg = Tcl_GetStringFromObj(msgObj, &templength);
    rc = sendto(g_Client.handle, msg, templength, 0, 
                (struct sockaddr *) &g_Client.remoteServAddr, 
                sizeof(g_Client.remoteServAddr));
  
    if(rc<0) {
        Tcl_AppendStringsToObj(result, "utracker: cannot send data ",
                               Tcl_GetString(msgObj), (char *)NULL);
        if (msgObj) Tcl_DecrRefCount(msgObj);
        /* re-initialize socket next time around*/
        g_Client.ready = 0;
        return TCL_ERROR;
    }

    /* Return the memory to the system */
    if (msgObj) Tcl_DecrRefCount(msgObj);
    return TCL_OK;

}


STUB_EXPVAL int AX_BORLAND_EXPORT Utracker_Init(Tcl_Interp *interp) {
#ifdef USE_TCL_STUBS
    char *ptr;

    ptr = Tcl_InitStubs(interp, "8.1", 0); /* Need at least 8.1 but not exact */
    if (! ptr) /* Fail upon stub incompatibility */
        return TCL_ERROR;
#endif    

    /* This will introduce the "utracker" command to the interpreter. */

    memset(&g_Client, 0, sizeof(g_Client));
    g_Client.handle = INVALID_SOCKET;
    Tcl_CreateObjCommand(interp, "utracker", udpc, NULL, NULL);
    Tcl_DStringInit(&g_Client.server);

    /* Create package */
    Tcl_PkgProvide(interp, "utracker", "1.2");
  
    return TCL_OK;
}


