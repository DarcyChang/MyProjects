======================================================================
Spirent HLTAPI  (hltapi_stc_4.46)                 Date: 01/05/15
======================================================================


Table of Contents
-----------------
        System Requirements (special):
        APIs Supported:
        Changes:
        Key Known Issues:
        General Restrictions:
        Installation Instructions (special):
        

System Requirements (special):
        This release supports Single Processor, Dual Processor, Windows, Enterprise Linux 3, RedHat 8.0
        This release supports Spirent TestCenter Release 4.40/4.46
        TCL 8.4.13
        Cards: MSA2001A/B EDM-2003A, XFP-2001A/B, CPR2001A/B, CPR2002A/B, EDM2001A/B, FBR2001A/B, UPY2001A, UPY2002A, WAN2002A, XFP-4004A, SFP-4001A, CM, CV, DX/DX2, FX/FX2, MX/MX2, VM


APIs Supported:
        Session API
        Alarms
        Traffic API
        Test_config/Test_control
        40G/100G port suport
        Capture, Capture Filter
        BGPv4, BGPv6
        DHCPv4,DHCPv6,DHCP-PD
        STP
        IGMPv1, IGMPv2, IGMPv3, IGMPv1 Querier, IGMPv2 Querier, IGMPv3 Querier
        IS-IS IPv4, IS-IS IPv6
        IPv6 Autoconfiguration
        LDP IPv4
        MLDv1, MLDv2
        Multicast groups
        OSPFv2, OSPFv3
        OSPF Topology
        Ping
        PIM
        PPP, PPPoX/IPv4, pppox server, L2TP
        RIPv1, RIPv2, RIPng 
        RSVP IPv4
        Route flapping for BGP, IS-IS, OSPF, RIP
        BFD
        L2TP
        Graceful restart for BGP, IS-IS, LDP, OSPF, RSVP
        GRE for RSVP, BGP, LDP, OSPF, PIM, RIP
        ATM for BGP, ISIS, OSPF, PPPOx, Pppox Server, RIP, ANCP, L2TP, DHCP, DHCP server
        Ethernet OAM 
        Ethernet EFM
        MVPN
        ANCP
        RFC2544, RFC3918
        LACP
        SIP
        FCOE/FIP, FC
        LLDP
        PTP
        Lab Server mode support
        802.1x
        MPLS-TP
        CFM PDUs Capture Filters.
        Save to High Level API
        Configure multiple protocols on the same device, including RSVP/IGMP/LDP/RIP/OSPFV2/OSPFV3/ISIS/BGP/DHCPV6/DHCPV6PD/DHCPV4/PIM/SIP/MLD/IGMP QUERIER.
        VxLan
        HLTAPI for Perl
        HLTAPI for Python
        Save as iTest
        40G/100G L1 API

Changes:
        (from release 4.40 to release 4.46):
        a) New features: 
           40G/100G L1 API

        b) Enhancement:
            1-2179073801  GRE encapsulation and L2GreTunnelLink support in HLTAPI
            1-1018031272  Support for fetching results without saving results in .db file in HLTAPI.
            1-428851058   Support for "Auto" Frame size in HLTAPI
            1-443455868   HLTAPI Enhancement in "sth:traffic_control" API to disable/enable ARP on streamblocks
            1-748213012   Feature request for IPv6 address ping in HLTAPI
            1-2257611896  Need ::sth::link_config support in hltgen
            1-2257611896  Support abort in emulation_dhcp_control - Implemented review Comments
            1-2242330398  HLTAPI needs an arp CMD for StreamBlock, the interface config options does not cover all cases.

        c) Issue resolutions:
            1-2184303015  HLTAPI "emulation_mld_config", subscribes to some results without checking to see if there is an existing subscription.
            1-2170821876  Interface_config API is not reflected in saved script through SavetoHLTAPI for speed 2/4/8G FC card
            1-2113570123  can't read "modeCount": no such variable
                          Enabling "relay_agent_flag" while configuring emulation_dhcp_config in HLTAPI should populate only "relay agent circuit" field in GUI

Key Known Issues:
    None 


Installation Instructions:
        Windows, Enterprise Linux 3, RedHat 8.0
        a) Install Spirent P4.46 HLTAPI:
        gunzip hltapi.tar.gz
        tar -vxf hltapi.tar in /tcl/lib folder
        hltapi folder will be created after untarred