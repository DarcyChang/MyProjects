######################################################################################################
#
# Title         :  HLTAPI_PYTHON_PPPoE_Config.pl                   
# Purpose       :  The purpose of this script is to configure PPPoE client and Server
#
# Body   : Step 1. Connect to a pair of STC ports connected B2B                                
#          Step 2. Create PPPoE client and PPPoE server on each STC ports
#          Step 3. Check for PPPoE client and server status
#
# Pass/Fail Criteria:  Script passes if
#                                                                                              
#            Step 1. Connect and reserve successfully                                                                 
#             
#                                                                                                                              
# Pre-requisites :  1) A pair of STC ports connected to B2B
#                                                                                                                              
# Software Req  :   SpirentTestCenter package, HLTAPI 4.40 GA and above                                                                       
#                                                                                                                
# To run this script : python HLTAPI_PYTHON_PPPoE_Config.py
##############################################################################################################
import sth
import time
##############################################################
#config the parameters for the logging
##############################################################

test_sta = sth.test_config (
        log                                              = '1',
        logfile                                          = 'pppoe_logfile',
        vendorlogfile                                    = 'pppoe_stcExport',
        vendorlog                                        = '1',
        hltlog                                           = '1',
        hltlogfile                                       = 'pppoe_hltExport',
        hlt2stcmappingfile                               = 'pppoe_hlt2StcMapping',
        hlt2stcmapping                                   = '1',
        log_level                                        = '7');

status = test_sta['status']
if (status == '0') :
    print "run sth.test_config failed"
    print test_sta
else:
    print "***** run sth.test_config successfully"


##############################################################
#config the parameters for optimization and parsing
##############################################################

test_ctrl_sta = sth.test_control (
        action                                           = 'enable');

status = test_ctrl_sta['status']
if (status == '0') :
    print "run sth.test_control failed"
    print test_ctrl_sta
else:
    print "***** run sth.test_control successfully"


##############################################################
#connect to chassis and reserve port list
##############################################################

i = 0
device = "10.62.224.11"
port_list = ['1/1','1/2']
port_handle = []
intStatus = sth.connect (
        device                                           = device,
        port_list                                        = port_list,
        offline                                          = 0 )

status = intStatus['status']

if (status == '1') :
    for port in port_list :
        port_handle.append(intStatus['port_handle'][device][port])
        print "\n reserved ports",port,":", port_handle[i]
        i += 1
else :
    print "\nFailed to retrieve port handle!\n"
    print port_handle

##############################################################
#interface config
##############################################################

int_ret0 = sth.interface_config (
        mode                                             = 'config',
        port_handle                                      = port_handle[0],
        intf_mode                                        = 'ethernet',
        duplex                                           = 'full',
        autonegotiation                                  = '1');

status = int_ret0['status']
if (status == '0') :
    print "run sth.interface_config failed"
    print int_ret0
else:
    print "***** run sth.interface_config successfully"

int_ret1 = sth.interface_config (
        mode                                             = 'config',
        port_handle                                      = port_handle[1],
        intf_mode                                        = 'ethernet',
        duplex                                           = 'full',
        autonegotiation                                  = '1');

status = int_ret1['status']
if (status == '0') :
    print "run sth.interface_config failed"
    print int_ret1
else:
    print "***** run sth.interface_config successfully"


##############################################################
#create device and config the protocol on it
##############################################################

#start to create the device: Host 3
device_ret0 = sth.pppox_server_config (
        mode                                             = 'create',
        encap                                            = 'ethernet_ii',
        protocol                                         = 'pppoe',
        ipv4_pool_addr_prefix_len                        = '24',
        ipv4_pool_addr_count                             = '1',
        ipv4_pool_addr_step                              = '1',
        ipv4_pool_addr_start                             = '10.1.1.10',
        port_handle                                      = port_handle[1],
        max_outstanding                                  = '100',
        disconnect_rate                                  = '1000',
        attempt_rate                                     = '100',
        enable_osi                                       = 'false',
        pap_req_timeout                                  = '3',
        mru_neg_enable                                   = '1',
        max_configure_req                                = '10',
        term_req_timeout                                 = '3',
        max_terminate_req                                = '10',
        username                                         = 'spirent',
        force_server_connect_mode                        = 'false',
        echo_vendor_spec_tag_in_pado                     = 'false',
        echo_vendor_spec_tag_in_pads                     = 'false',
        max_payload_tag_enable                           = 'false',
        max_ipcp_req                                     = '10',
        echo_req_interval                                = '10',
        config_req_timeout                               = '3',
        local_magic                                      = '1',
        password                                         = 'spirent',
        chap_reply_timeout                               = '3',
        max_chap_req_attempt                             = '10',
        enable_mpls                                      = 'false',
        lcp_mru                                          = '1492',
        ip_cp                                            = 'ipv4_cp',
        max_echo_acks                                    = '0',
        auth_mode                                        = 'none',
        include_id                                       = '1',
        ipcp_req_timeout                                 = '3',
        server_inactivity_timer                          = '30',
        unconnected_session_threshold                    = '0',
        max_payload_bytes                                = '1500',
        echo_req                                         = 'false',
        fsm_max_naks                                     = '5',
        mac_addr                                         = '00:10:94:00:00:04',
        mac_addr_step                                    = '00:00:00:00:00:01',
        intf_ip_prefix_length                            = '24',
        intf_ip_addr                                     = '10.1.1.2',
        gateway_ip_addr                                  = '10.1.1.1',
        intf_ip_addr_step                                = '0.0.0.1',
        gateway_ip_step                                  = '0.0.0.0',
        num_sessions                                     = '1');

status = device_ret0['status']
if (status == '0') :
    print "run sth.pppox_server_config failed"
    print device_ret0
else:
    print "***** run sth.pppox_server_config successfully"

#start to create the device: Host 4
device_ret1 = sth.pppox_config (
        mode                                             = 'create',
        encap                                            = 'ethernet_ii',
        protocol                                         = 'pppoe',
        ac_select_mode                                   = 'service_name',
        circuit_id_suffix_mode                           = 'none',
        port_handle                                      = port_handle[0],
        max_outstanding                                  = '100',
        disconnect_rate                                  = '1000',
        attempt_rate                                     = '100',
        pppoe_circuit_id                                 = 'circuit',
        mru_neg_enable                                   = '1',
        max_configure_req                                = '10',
        chap_ack_timeout                                 = '3',
        max_padi_req                                     = '10',
        padi_include_tag                                 = '1',
        padr_req_timeout                                 = '3',
        max_terminate_req                                = '10',
        term_req_timeout                                 = '3',
        username                                         = 'spirent',
        use_partial_block_state                          = 'false',
        max_auto_retry_count                             = '65535',
        agent_type                                       = '2516',
        max_ipcp_req                                     = '10',
        intermediate_agent                               = 'false',
        echo_req_interval                                = '10',
        password                                         = 'spirent',
        local_magic                                      = '1',
        config_req_timeout                               = '3',
        active                                           = '1',
        auto_retry                                       = 'false',
        padi_req_timeout                                 = '3',
        agent_mac_addr                                   = '00:00:00:00:00:00',
        lcp_mru                                          = '1492',
        ip_cp                                            = 'ipv4_cp',
        auto_fill_ipv6                                   = '1',
        max_echo_acks                                    = '0',
        auth_mode                                        = 'none',
        include_id                                       = '1',
        ipcp_req_timeout                                 = '3',
        max_padr_req                                     = '10',
        padr_include_tag                                 = '1',
        echo_req                                         = 'false',
        fsm_max_naks                                     = '5',
        mac_addr                                         = '00:10:94:00:00:03',
        mac_addr_repeat                                  = '0',
        mac_addr_step                                    = '00:00:00:00:00:01',
        intf_ip_addr                                     = '10.1.1.1',
        gateway_ip_addr                                  = '10.1.1.2',
        intf_ip_addr_step                                = '0.0.0.1',
        gateway_ip_step                                  = '0.0.0.0',
        num_sessions                                     = '1');

status = device_ret1['status']
if (status == '0') :
    print "run sth.pppox_config failed"
    print device_ret1
else:
    print "***** run sth.pppox_config successfully"

#config part is finished

##############################################################
#start devices
##############################################################

device_list = device_ret0['handle'].split()[0]

ctrl_ret1 = sth.pppox_server_control (
        handle                                           = device_list,
        action                                           = 'connect');

status = ctrl_ret1['status']
if (status == '0') :
    print "run sth.pppox_server_control failed"
    print ctrl_ret1
else:
    print "***** run sth.pppox_server_control successfully"

device_list = device_ret1['handle'].split()[0]

ctrl_ret2 = sth.pppox_control (
        handle                                           = device_list,
        action                                           = 'connect');

status = ctrl_ret2['status']
if (status == '0') :
    print "run sth.pppox_control failed"
    print ctrl_ret2
else:
    print "***** run sth.pppox_control successfully"

time.sleep ( 10 );

##############################################################
#start to get the device results
##############################################################

device = device_ret0['handle'].split()[0]

results_ret1 = sth.pppox_server_stats (
        handle                                           = device,
        mode                                             = 'aggregate');

status = results_ret1['status']
if (status == '0') :
    print "run sth.pppox_server_stats failed"
    print results_ret1
else:
    print "***** run sth.pppox_server_stats successfully, and results is:"
    print  results_ret1;

device = device_ret1['handle'].split()[0]

results_ret3 = sth.pppox_stats (
        handle                                           = device,
        mode                                             = 'aggregate');

status = results_ret3['status']
if (status == '0') :
    print "run sth.pppox_stats failed"
    print results_ret3
else:
    print "***** run sth.pppox_stats successfully, and results is:"
    print  results_ret3;

print "\nNumber of pppoe server sessions configured on port1:", results_ret1['aggregate']['num_sessions'];
print "\nNumber of pppoe server sessions up on port1:", results_ret1['aggregate']['sessions_up'];
print "\nNumber of pppoe client sessions configured on port2:" , results_ret3['aggregate']['sessions_up'];
print "\nNumber of pppoe client sessions up on port2:", results_ret3['aggregate']['num_sessions'];

##############################################################
#clean up the session, release the ports reserved and cleanup the dbfile
##############################################################

cleanup_sta = sth.cleanup_session (
        port_handle                                      = [port_handle[0],port_handle[1]],
        clean_dbfile                                     = '1');

status = cleanup_sta['status']
if (status == '0') :
    print "run sth.cleanup_session failed"
    print cleanup_sta
else:
    print "***** run sth.cleanup_session successfully"


print "**************Finish***************"
