#ifndef UDPCLIENT_H
#define UDPCLIENT_H
/*
  The license below applies only to udpClient.h udpClient.c, which
  were modified from source code provided by Cisco. Changes made by
  Spirent were to add in the TCL Stubs mechanism, various fixes to 
  so as to use with the pkg_mkIndex command and return errors via the 
  normal TCL mechansims.
  
*/

/* udpClient.h
  $Id: //TestCenter/p2_dev_HltApi/mainline/content/HltAPI/4.46/ReleasePackage/SourceCode/utracker/udpClient.h#1 $

  Copyright (C) July 15 2005 Craig Brown and Jerry Iseri

  This software is provided 'as-is', without any express or implied
  warranty.  In no event will the authors be held liable for any damages
  arising from the use of this software.

  Permission is granted to anyone to use this software for any purpose,
  including commercial applications, and to alter it and redistribute it
  freely, subject to the following restrictions:

  1. The origin of this software must not be misrepresented; you must not
     claim that you wrote the original software. If you use this software
     in a product, an acknowledgment in the product documentation would be
     appreciated but is not required.
  2. Altered source versions must be plainly marked as such, and must not be
     misrepresented as being the original software.
  3. This notice may not be removed or altered from any source distribution.

  Craig Brown             Jerry Iseri
  crbrown@cisco.com       Jerry.Iseri@Spirentcom.com

*/


#if (defined(__WIN32__) || defined(_WIN32) || defined(WIN32))
   #define WIN32_LEAN_AND_MEAN
   #include <winsock.h>
   #undef WIN32_LEAN_AND_MEAN
   typedef enum { AX_FALSE=0, AX_TRUE=1} AX_BOOLEAN;
#define WIN_32
#else

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <stdio.h>      /* Standard Output */
#include <unistd.h>
#include <string.h>    
#include <sys/time.h>   /* select() */ 
#include <errno.h>
#endif




#endif
