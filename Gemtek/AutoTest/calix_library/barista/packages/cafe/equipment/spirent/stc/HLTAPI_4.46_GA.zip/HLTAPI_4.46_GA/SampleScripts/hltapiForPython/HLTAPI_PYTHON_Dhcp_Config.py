#########################################################################################################################
#
# Title         :  HLTAPI_PYTHON_Dhcp_Config.pl                   
# Purpose       :  The purpose of this script is to configure DHCP client and server
#
# Body   : Step 1. Connect to a pair of STC ports connected B2B                                
#          Step 2. create DHCP client on STC port and DHCP server on other STC port
#          Step 3. Check for DHCP server and client status
#
# Pass/Fail Criteria:  Script passes if
#            Step 1. Connect and reserve successfully                       
#             
#                                                                          
# Pre-requisites :  1) A pair of STC ports connected to B2B
#                                                                          
# Software Req  :   SpirentTestCenter package, HLTAPI 4.40 GA and above    
#                                                                          
# To run this script : python HLTAPI_PYTHON_Dhcp_Config.py 
#
#########################################################################################################################
import sth
import time
##############################################################
#config the parameters for the logging
##############################################################

test_sta = sth.test_config (
        log                                              = '1',
        logfile                                          = 'dhcp_logfile',
        vendorlogfile                                    = 'dhcp_stcExport',
        vendorlog                                        = '1',
        hltlog                                           = '1',
        hltlogfile                                       = 'dhcp_hltExport',
        hlt2stcmappingfile                               = 'dhcp_hlt2StcMapping',
        hlt2stcmapping                                   = '1',
        log_level                                        = '7');

status = test_sta['status']
if (status == '0') :
    print "run sth.test_config failed"
    print test_sta
else:
    print "***** run sth.test_config successfully"


##############################################################
#config the parameters for optimization and parsing
##############################################################

test_ctrl_sta = sth.test_control (
        action                                           = 'enable');

status = test_ctrl_sta['status']
if (status == '0') :
    print "run sth.test_control failed"
    print test_ctrl_sta
else:
    print "***** run sth.test_control successfully"


##############################################################
#connect to chassis and reserve port list
##############################################################

i = 0
device = "10.62.224.11"
port_list = ['1/1','1/2']
port_handle = []
intStatus = sth.connect (
        device                                           = device,
        port_list                                        = port_list,
        offline                                          = 0 )

status = intStatus['status']

if (status == '1') :
    for port in port_list :
        port_handle.append(intStatus['port_handle'][device][port])
        print "\n reserved ports",port,":", port_handle[i]
        i += 1
else :
    print "\nFailed to retrieve port handle!\n"
    print port_handle


##############################################################
#interface config
##############################################################

int_ret0 = sth.interface_config (
        mode                                             = 'config',
        port_handle                                      = port_handle[0],
        intf_mode                                        = 'ethernet',
        duplex                                           = 'full',
        autonegotiation                                  = '1');

status = int_ret0['status']
if (status == '0') :
    print "run sth.interface_config failed"
    print int_ret0
else:
    print "***** run sth.interface_config successfully"

int_ret1 = sth.interface_config (
        mode                                             = 'config',
        port_handle                                      = port_handle[1],
        intf_mode                                        = 'ethernet',
        duplex                                           = 'full',
        autonegotiation                                  = '1');

status = int_ret1['status']
if (status == '0') :
    print "run sth.interface_config failed"
    print int_ret1
else:
    print "***** run sth.interface_config successfully"


##############################################################
#create device and config the protocol on it
##############################################################

#start to create the device: Host 3
device_ret0 = sth.emulation_dhcp_server_config (
        mode                                             = 'create',
        ip_version                                       = '4',
        encapsulation                                    = 'ETHERNET_II',
        ipaddress_count                                  = '245',
        ipaddress_pool                                   = '10.1.1.10',
        ipaddress_increment                              = '1',
        port_handle                                      = port_handle[1],
        lease_time                                       = '3600',
        ip_repeat                                        = '0',
        remote_mac                                       = '00:00:01:00:00:01',
        ip_address                                       = '10.1.1.2',
        ip_prefix_length                                 = '24',
        ip_gateway                                       = '10.1.1.1',
        ip_step                                          = '0.0.0.1',
        local_mac                                        = '00:10:94:00:00:02',
        count                                            = '1');

status = device_ret0['status']
if (status == '0') :
    print "run sth.emulation_dhcp_server_config failed"
    print device_ret0
else:
    print "***** run sth.emulation_dhcp_server_config successfully"

#start to create the device: Host 4
device_ret1port = sth.emulation_dhcp_config (
        mode                                             = 'create',
        ip_version                                       = '4',
        port_handle                                      = port_handle[0],
        starting_xid                                     = '0',
        lease_time                                       = '60',
        outstanding_session_count                        = '1000',
        request_rate                                     = '100',
        msg_timeout                                      = '60000',
        retry_count                                      = '4',
        max_dhcp_msg_size                                = '576',
        release_rate                                     = '100');

status = device_ret1port['status']
if (status == '0') :
    print "run sth.emulation_dhcp_config failed"
    print device_ret1port
else:
    print "***** run sth.emulation_dhcp_config successfully"

dhcp_handle = device_ret1port['handles']

device_ret1 = sth.emulation_dhcp_group_config (
        mode                                             = 'create',
        dhcp_range_ip_type                               = '4',
        encap                                            = 'ethernet_ii',
        handle                                           = dhcp_handle,
        opt_list                                         = ['1','6','15','33','44'],
        host_name                                        = 'client_@p-@b-@s',
        ipv4_gateway_address                             = '192.85.2.1',
        mac_addr                                         = '00:10:94:00:00:01',
        mac_addr_step                                    = '00:00:00:00:00:01',
        num_sessions                                     = '1');

status = device_ret1['status']
if (status == '0') :
    print "run sth.emulation_dhcp_group_config failed"
    print device_ret1
else:
    print "***** run sth.emulation_dhcp_group_config successfully"

#config part is finished

##############################################################
#start devices
##############################################################

ctrl_ret1 = sth.emulation_dhcp_server_control (
        port_handle                                      = port_handle[1],
        action                                           = 'connect',
        ip_version                                       = '4');

status = ctrl_ret1['status']
if (status == '0') :
    print "run sth.emulation_dhcp_server_control failed"
    print ctrl_ret1
else:
    print "***** run sth.emulation_dhcp_server_control successfully"

ctrl_ret2 = sth.emulation_dhcp_control (
        port_handle                                      = port_handle[0],
        action                                           = 'bind',
        ip_version                                       = '4');

status = ctrl_ret2['status']
if (status == '0') :
    print "run sth.emulation_dhcp_control failed"
    print ctrl_ret2
else:
    print "***** run sth.emulation_dhcp_control successfully"

time.sleep( 10 )
##############################################################
#start to get the device results
##############################################################

results_ret1 = sth.emulation_dhcp_server_stats (
        port_handle                                      = port_handle[1],
        action                                           = 'COLLECT',
        ip_version                                       = '4');

status = results_ret1['status']
if (status == '0') :
    print "run sth.emulation_dhcp_server_stats failed"
    print results_ret1
else:
    print "***** run sth.emulation_dhcp_server_stats successfully, and results is:"
    print  results_ret1;

results_ret2 = sth.emulation_dhcp_stats (
        port_handle                                      = port_handle[0],
        action                                           = 'collect',
        mode                                             = 'session',
        ip_version                                       = '4');

status = results_ret2['status']
if (status == '0') :
    print "run sth.emulation_dhcp_stats failed"
    print results_ret2
else:
    print "***** run sth.emulation_dhcp_stats successfully, and results is:"
    print  results_ret2;

print "\nclients bound : ", results_ret2['group']['dhcpv4blockconfig1']['total_bound'];

##############################################################
#clean up the session, release the ports reserved and cleanup the dbfile
##############################################################

cleanup_sta = sth.cleanup_session (
        port_handle                                      = [port_handle[0],port_handle[1]],
        clean_dbfile                                     = '1');

status = cleanup_sta['status']
if (status == '0') :
    print "run sth.cleanup_session failed"
    print cleanup_sta
else:
    print "***** run sth.cleanup_session successfully"


print "**************Finish***************"
